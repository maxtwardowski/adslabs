#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main()
{
	
	
	FILE *text;
	FILE *dictionary;
    
	dictionary = fopen ("wrt.dic","r") ;
    text = fopen( "ocr_output.txt","r");
    char buffer[20];
    
    while (fscanf(text, "%s", buffer) == 1)
    {
    	if(strlen(buffer)>1)
	{
		
    }
    if(feof(text))
    {
    printf("end of file\n");
    return 0;}
    
	fclose(text);
	fclose(dictionary);	
		
	return 0;
    }
